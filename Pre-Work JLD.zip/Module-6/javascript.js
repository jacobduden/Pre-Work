$("#grow").on("click", function() {
    $("#box").animate({height:"+=250px", width:"+=250px"}, "fast");
})
$("#fade").on("click", function() {
   $("#box").fadeOut()
})
$("#changecolor").on("click", function(){
    $("#box").css("background-color", "blue")
})
$("#resetbox").on("click", function(){
    $("#box").fadeIn()
    $("#box").css({"background-color": "orange", "width":"150px", "height":"150px"})
})